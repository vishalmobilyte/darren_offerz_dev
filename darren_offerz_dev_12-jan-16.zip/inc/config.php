<?php session_start();
	include('db_connection.php');
	//include('functions.php');
	
	?>