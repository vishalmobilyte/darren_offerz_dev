<?php 
	session_start();
	ini_set('error_reporting','1');
	error_reporting( E_ALL );
	ini_set('display_errors','-1');
	// print_r($_SERVER); die;	
	include('inc/db_connection.php');
	include('inc/functions.php');
	?>